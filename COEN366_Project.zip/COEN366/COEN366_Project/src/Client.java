import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;



public class Client implements Runnable {
	//Enumerator used for broadcasting a shutdown signal to the while(RUNNING) loop of Peer_TCP_Client
	//Enumerator used for specifying how to test
	protected enum State {RUNNING,SHUTDOWN};
	private enum InputMode{FILE, CONSOLE, FILE_THEN_CONSOLE};
	protected static State broadcastState = State.RUNNING;
	
	//Variables used for UDP communication with Server
	protected static int server_udp_portNum;
	protected static int serverRQ;
	protected DatagramSocket datagramSocket;
	protected InetAddress inetAddress;
	protected ArrayList<String> listFileNames;
	
	//Socket used to listen for incoming TCP messages
	protected static ServerSocket tcp_serverSocket;
	
	//The ip and port that the Peer_TCP_Client thread will connect and send to
	protected String tcp_destIP = "";
	protected int tcp_destPort = 0;
	
	protected static int peerRQ;
	
	//This Client's name, set with REGISTER
	protected String clientName;
	
	
	
	
	
    public Client() {
    	
    }
    
	public Client(DatagramSocket datagramSocket, InetAddress inetAddress) {
	    this.datagramSocket = datagramSocket;
	    this.inetAddress = inetAddress;
	    serverRQ = 0; // every client will start with a request number of 0
	    listFileNames = new ArrayList<String>();
	}   

	public void setClientName(String clientName){
		this.clientName = clientName;
	}

	public String insertServerRQ(String message) {
		String serverRQNum = String.valueOf(serverRQ);
	    String splitMessage[] = message.split(" ");
	    String instruction = splitMessage[0].toUpperCase();
	    
	    String newMessage = instruction;
	    newMessage = newMessage + " " + serverRQNum;
	 	for (int i = 1; i < splitMessage.length; i++) {
	 		newMessage = newMessage + " " + splitMessage[i];
	 	}
	 	return newMessage;
	}
	
	public String insertPeerRQ(String message) {
		String peerRQNum = String.valueOf(peerRQ);
	    String splitMessage[] = message.split(" ");
	    String instruction = splitMessage[0].toUpperCase();
	    
	    String newMessage = instruction;
	    newMessage = newMessage + " " + peerRQNum;
	 	for (int i = 1; i < splitMessage.length; i++) {
	 		newMessage = newMessage + " " + splitMessage[i];
	 	}
	 	return newMessage;
	}
	
	public void parser(String msg) throws InterruptedException {
		String msgComponents[] = msg.split(" ");
		String instruction = msgComponents[0].toUpperCase();
		
		switch (instruction) {
        case "REGISTER":{ 
        	//Set the local name of the client
        	setClientName(msgComponents[1]); 
        	
        	//Build message to send
        	msg = insertServerRQ(msg);
        	msg = msg + " " + datagramSocket.getLocalPort() + " " + tcp_serverSocket.getLocalPort();
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "DE-REGISTER":{  
        	//Build message to send
        	msg = insertServerRQ(msg);
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "PUBLISH":{
        	//Check that the publish request is the right size
        	if (msgComponents.length != 3) {
        		System.out.println("PUBLISH message not sent. Wrong packet size.");
        		break;
        	}
        	
        	//If the file name exists, add it to listFileNames iff not a duplicate
        	String[] list = msgComponents[2].split(",");
        	String listSent = new String();
        	String listNotSent = new String();
        	
        	for (String fn : list) {
        		File fileChecker = new File(fn);
        		if (fileChecker.isFile()) {
        			if (!listFileNames.contains(fn))
        				listFileNames.add(fn);
        			listSent = listSent + fn + ",";
        		}
        		else {
        			listNotSent = listNotSent + fn + ",";
        		}
        	}
        	
        	//Removes the comma at the end of the lists and lets the client know that certain files were not published
        	if (listSent!=null && listSent.length()>0 && listSent.charAt(listSent.length()-1)==',') {
        		listSent = listSent.substring(0, listSent.length()-1);
            }
        	if (listNotSent!=null && listNotSent.length()>0 && listNotSent.charAt(listNotSent.length()-1)==',') {
        		listNotSent = listNotSent.substring(0, listNotSent.length()-1);
        		System.out.println("Files: " + listNotSent + " not published because they do not exist");
        	}
        	
        	//Check that there are files
        	if (listSent.isEmpty()) {
        		System.out.println("PUBLISH message not sent. No files available to publish.");
        		break;
        	}
        	
        	//Build message to send
        	msg = instruction + " " + serverRQ + " " + msgComponents[1] + " " + listSent;
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "REMOVE":{
        	//Does not remove the fileName from the listFileNames.
        	
        	//Build message to send
        	msg = insertServerRQ(msg);
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "RETRIEVE-ALL":{
        	//Build message to send
        	msg = insertServerRQ(msg);
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "RETRIEVE-INFOT":{
        	//Build message to send
        	msg = insertServerRQ(msg);
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

        case "SEARCH-FILE":{
        	//Build message to send
        	msg = insertServerRQ(msg);
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
        	Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
        	break;
        }

		case "UPDATE-CONTACT":{
			//Build message to send
			msg = insertServerRQ(msg);
        	msg = msg + " " + datagramSocket.getLocalPort() + " " + tcp_serverSocket.getLocalPort();
        	
        	//Create new Peer_UDP_Handler class as a thread. Pass the msg to it in the constructor. Start the thread and wait for it to die.
			Thread udpHandlerThread = new Thread(new Peer_UDP_Handler(datagramSocket,inetAddress,msg));
        	udpHandlerThread.start();
        	udpHandlerThread.join();
			break;
		}
		
		case "SET-TARGET": {
			//[SET-TARGET|destIP|destPort]
			if (msgComponents.length == 3) {
				
				//Set client variables and print target info
				tcp_destIP = msgComponents[1];
				tcp_destPort = Integer.parseInt(msgComponents[2]);
				System.out.println("Targeted -> " + tcp_destIP + ":"+ tcp_destPort);
				break;
			}
			
			//Print wrong packet warning
			System.out.println("Wrong packet size for TARGET-PEER");
			break;
		}
		
		case "DOWNLOAD":{
			if(tcp_destIP.isEmpty() || tcp_destPort == 0) {
				System.out.println("Target not set");
				break;
			}
			
			serverRQ++;
			
			//create [DOWNLOAD RQ filename] message
			msg = insertPeerRQ(msg);
			
			//Sends the msg, destIP, and destPort to Peer_TCP_Client thread. Start and wait for thread to die.
			Thread PeerTCPClientThread = new Thread(new Peer_TCP_Client(msg,tcp_destIP,tcp_destPort));
			PeerTCPClientThread.start();
			PeerTCPClientThread.join();
			break;
		}

        default:{
        	System.out.println(instruction + " is not a valid instruction");
        	break;
        }
        }

	}

	public static void main(String[]args) throws InterruptedException, IOException {
		/** SPECIFY IF YOU WANT TO READ FROM FILE, CONSOLE, FILE_THEN_CONSOLE **/
		/**         IF YOU WANT TO READ FROM FILE, SPECIFY FILE NAME!         **/
		InputMode inputMode = InputMode.CONSOLE;
		String fileToRead = new String("tester.txt");
		
		/** SPECIFY THE PORT NUMBER OF MAIN SERVER **/
		/**       (THIS IS FROM SERVER.JAVA)       **/
		server_udp_portNum = 3000;
		
		//Set the port number for the tcp listener. 0 is used so that a port number is automatically allocated.
		tcp_serverSocket = new ServerSocket(0); 
		
		//Prompt for UDP packet destination as console input
		System.out.print("Enter the IP address of the P2P server: ");
		
		//Start a scanner object in the terminal of Client.java
		Scanner scanner = new Scanner(System.in);
		String ip = scanner.nextLine();
		
		//Set the destination address for UDP communications
		InetAddress inetAddress = InetAddress.getByName(ip);
		
		//Instantiate an instance of client. This is necessary since parser() cannot be a static method
		Client client = new Client(new DatagramSocket(),inetAddress);
		
		//Start listening for incoming tcp messages (by starting the tcpServerThread)
		Thread tcpServerThread = new Thread(new Peer_TCP_Server());
		tcpServerThread.start();
		
		//Thread thread = new Thread(client); // look at run method
		//thread.start();

		//Deal with Client.java input here
		switch(inputMode) {
		case FILE:{
			BufferedReader reader;
			reader = new BufferedReader(new FileReader(fileToRead));
			String currentLine;
			while((currentLine = reader.readLine()) != null){
				client.parser(currentLine);
			}
			reader.close();		
		}
		case CONSOLE: {
			while (true) {
				String input = scanner.nextLine();
				if (input.equals("SHUTDOWN")) {
					broadcastState = State.SHUTDOWN;
					scanner.close();
					tcpServerThread.interrupt();
					break;
				}else {
					client.parser(input);
				}
			}
			break;
		}
		case FILE_THEN_CONSOLE:{
			BufferedReader reader;
			reader = new BufferedReader(new FileReader(fileToRead));
			String currentLine;
			while((currentLine = reader.readLine()) != null){
				client.parser(currentLine);
			}
			reader.close();
				
			while (true) {
					
				String input = scanner.nextLine();
				if (input.equals("SHUTDOWN")) {
					broadcastState = State.SHUTDOWN;
					scanner.close();
					tcpServerThread.interrupt();
					break;
				}else {
					client.parser(input);
				}
			}
			break;
		}
		default:break;}
		
		
		
		System.out.println("Client.java has been SHUTDOWN");
		System.exit(0);
	}

    // Runnable method called when starting thread object
    @Override
    public void run() {
        System.out.println("Client thread running");
		//Thread tcpServerThread = new Thread(new Peer_TCP_Server());
		//Thread tcpClientThread = new Thread(new Peer_TCP_Client());
		//tcpServerThread.start(); // Server port of the client
		//tcpClientThread.start(); // connection thread of the client
		// I think the order should be switched




    }
}
