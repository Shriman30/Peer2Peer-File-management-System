import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server implements Runnable {
	private File client_list_File; // contains the list of clients that are registerd to the P2P network
	private static int server_udp_portNum = 3000; // placeholder for the UDP socket port number. Remains fixed
    private DatagramSocket udp_datagramSocket; // socket through which server will be listening from
    private DatagramPacket udp_datagramPacket_in, udp_datagramPacket_out = null; 
    private int RQserver = 0; // Server should be used this variable to respond to the appropriate clients' RQ#
    private String RQclient; // Placeholder to store the RQ of the client
    
    private byte[] buffer = new byte[256]; // byte array to store messages
    

    // constructor
    public Server(DatagramSocket datagramSocket){
        this.udp_datagramSocket = datagramSocket;
    }

	// method used to print the received  instruction to the console
    public void instructionPrinter(String instruction) {
    	// This method is used to print to console which instruction was recieved
    	//This should output to a log file if that is implemented
    	System.out.print("Server:instructionPrinter()\t\t");
    	switch (instruction) {
	         case "REGISTER":{
	         	System.out.println("Registration request acknowledged");
	         	break;
	         }
	         case "DE-REGISTER":{
	         	System.out.println("De-Registration request acknowledged");
	         	break;
	         }
	         case "PUBLISH":{
	         	System.out.println("Publish request acknowledged");
	         	break;
	         }
	         case "REMOVE":{
	         	System.out.println("Remove request acknowledged");
	         	break;
	         }
	         case "RETRIEVE-ALL":{
	         	System.out.println("Retrieve-all request acknowledged");
	         	break;
	         }
	         case "RETRIEVE-INFOT":{
	         	System.out.println("Retrieve-infot request acknowledged");
	         	break;
	         }
	         case "SEARCH-FILE":{
	         	System.out.println("Search-File request acknowledged");
	         	break;
	         }
			case "UPDATE-CONTACT":{
				System.out.println("Update-Contact Request acknowledged");

			}
	         default :{
	         	System.out.println("Unknown Instruction : " + instruction);
	         	break;
	         }
         }
    }

    public void set_client_list(String sourcePath) {
    	//This method creates a file @ sourcePath and sets the private client_list_file to this File
    	try {
    	      client_list_File = new File(sourcePath);
    	      if (client_list_File.createNewFile()) {
    	        System.out.println("File created:\t" + client_list_File.getName());
    	      } else {
    	        System.out.println("File opened:\t" + client_list_File.getName());
    	      }
    	    } catch (IOException e) {
    	      System.out.println("An error occurred setting client_list_File.");
    	      e.printStackTrace();
    	    }
    }
    
    public boolean search_client_list(String clientName) {
    	//this method will search the client list for a name and return true if found
    	try {
    	  Scanner myReader = new Scanner(client_list_File);
    	  while (myReader.hasNext()) {
    	    String data = myReader.next();
    	    if (clientName.matches(data)) {
    	    	myReader.close();
    	    	return true;
    	    }
    	  }
    	  myReader.close();
    	  
    	} catch (FileNotFoundException e) {
    	  System.out.println("An error occurred searching client_list_File.");
    	  e.printStackTrace();
    	}
    	return false;	  
    }

	// search for the client in the client_list.txt file using its IP address.
	public boolean search_client_list_by_ip(String ip) {
		//this method will search the client list for a name and return true if found
		try {

			Scanner myReader = new Scanner(client_list_File);
			while (myReader.hasNext()) {
				String data = myReader.next();
				if (ip.matches(data)) {
					myReader.close();
					return true;
				}

			}
			myReader.close();

		} catch (FileNotFoundException e) {
			System.out.println("An error occurred searching client_list_File.");
			e.printStackTrace();
		}
		return false;
	}

	// returns the information of the clients that have already published the target file.
	public String search_client_list_by_file(String fileName) throws IOException, IndexOutOfBoundsException {
		//This method will search the client list for a file name and return "Name,IP,tcpPort"		
		BufferedReader reader = new BufferedReader(new FileReader(client_list_File));
		String listOf = new String();
		
		String currentLine = null;
		while((currentLine = reader.readLine()) != null){
			if(currentLine.contains(fileName)) {
				String splitLine[] = currentLine.split("\t");
				//splitLine[0]:Name , splitLine[1]:IP , splitLine[2]:udp_port, splitLine[3]:tcp_port, splitLine[4]:fileNames
				listOf = listOf + splitLine[0] + "," + splitLine[1] + "," + splitLine[3] + "|";
			}
		}
		
    	//Removes the "|" at the end of the list
    	if (listOf!=null && listOf.length()>0 && listOf.charAt(listOf.length()-1)=='|') {
    		listOf = listOf.substring(0, listOf.length()-1);
        }
		
		reader.close();
		return listOf;
	}

	// used to be called write_to_client_list. But changed it to register_client_to_list since this method is used only whenever we are registering.
    public void register_client_to_list(String clientName, String clientAddress,String udp_port,String tcp_port) {
    	//write the clientName and clientAddress to client_list
    	try {
    	      BufferedWriter bufWriter = new BufferedWriter(new FileWriter(client_list_File,true));
    	      bufWriter.append(clientName + "\t" + clientAddress + "\t" + udp_port + "\t" + tcp_port + "\t" + "\n");
    	      bufWriter.close();
    	      
    	      System.out.println("Wrote:\t\t\"" + clientName + " " + clientAddress + " " + udp_port + " " + tcp_port + "\" -> " + client_list_File.getName());
    	    } catch (IOException e) {
    	    	System.out.println("An error occurred writting to client_list_File.");
    	    	e.printStackTrace();
    	    }
    }

	// Used to publish a client's file upon request (if the file has not been published by the client yet).
	public void publish_to_clientFile(String clientName,String listOfFiles) throws IOException {
		File inputFile = client_list_File;
		File tempFile = new File("updated_client_list.txt");
		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String splitListofFiles[] = listOfFiles.split(",");
			
		String currentLine = new String();
		while((currentLine = reader.readLine()) != null){
			if(currentLine.contains(clientName)) {
				for (String str : splitListofFiles) {
					if (!currentLine.contains(str)) {	//check for duplicate
						currentLine = currentLine + str + ",";
					}else {
						System.out.println("Client File:\t" + str + " was already published");
					}
				}
			}
			writer.write(currentLine + System.getProperty("line.separator"));
			writer.flush();
		}
		writer.close();
		reader.close();
		inputFile.delete();
		tempFile.renameTo(inputFile);		
	}

	// removes the target file(s) requested by the client.
	public void remove_list_info_from_clientFile(String clientName,String listOfFiles) throws IOException {
		// This method is used to request the server to remove a file from the client's list of available files
		File inputFile = client_list_File;
		File tempFile = new File("updated_client_list.txt");
		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String splitListofFiles[] = listOfFiles.split(",");
			
		String currentLine = null;
		while((currentLine = reader.readLine()) != null){
			if(currentLine.contains(clientName)) {
				for (String str : splitListofFiles) {
					if (currentLine.contains(str + ",")) {
						currentLine = currentLine.replace(str+"," , "");		//removes the str,
						//currentLine = currentLine.replace(",,", ",");	//fixes the double-comma after removing
					}else {
						System.out.println("Client File:\t" + str + " was not published");
					}
				}
			}
			writer.write(currentLine + System.getProperty("line.separator"));
			writer.flush();
		}
		writer.close();
		reader.close();
		inputFile.delete();
		tempFile.renameTo(inputFile);		
	}

	// removes a client from the client_list.txt file during de-registration.
	public void remove_from_client_list(String clientName) throws IOException {
		File inputFile = client_list_File;
		File tempFile = new File("updated_client_list.txt");
		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
		String currentLine = null;
		
		while((currentLine = reader.readLine())!=null){
			if(currentLine.contains(clientName))continue;
			writer.write(currentLine+ System.getProperty("line.separator"));
			writer.flush();
		}
		writer.close();
		reader.close();
		inputFile.delete();
		tempFile.renameTo(inputFile);
	}
    
	

	// receives a message from the client then sends a message back to it according to the various protocols.
    public void receiveThenSendMessage(){

		//*** Might have to wrap all the big switch statement in an if-else clause to see limit one user per client*** IF WE HAVE TIME
        while(true){
            try{
				udp_datagramPacket_in = new DatagramPacket(buffer,buffer.length);
				udp_datagramSocket.receive(udp_datagramPacket_in); // get the message from client
				String messageFromClient = new String(udp_datagramPacket_in.getData(),0,udp_datagramPacket_in.getLength()); // store the message sent by the client in the string

				String messageComponents[] = messageFromClient.split(" "); // split the client message into an array of Strings
				String instruction = messageComponents[0].toUpperCase(); // convert first field of message to upper-case

				InetAddress clientAddress = udp_datagramPacket_in.getAddress(); // get the IP from client UDP Packet
				int clientPort = udp_datagramPacket_in.getPort(); // get the port number from the client UDP Packet
            	
				
				//instructionPrinter(instruction);
                System.out.println();
                
                switch (instruction) {
					// Registration protocol
                case "REGISTER":{ 
                	//Length 5 for (0)Instruction (1)RQ# (2)ClientName (3)UDP_Port (4)TCP_Port
                	if (messageComponents.length == 5) {
                		
                		//Set local variables and print the received message
                		RQclient = messageComponents[1];
	                	String clientName = messageComponents[2];
						String udp_port = messageComponents[3];
	                	String tcp_port = messageComponents[4];
	                    System.out.println("Received:\t[REGISTER|" + RQclient + "|" + clientName + "|" + udp_port + "|" + tcp_port + "]\tfrom IP: " + clientAddress + ":" + clientPort);
	                    
	                    //If the clientName is already registered
	                    if (search_client_list(clientName)) {
	                    	
	                    	//Send out registration denied packet
	                    	String returnMessage = "REGISTER-DENIED " + RQserver + " Name_Already_Registered";
	                    	udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
	                    	udp_datagramSocket.send(udp_datagramPacket_out);
	                    	
	                    	//Print registration denied packet and increase RQserver
	                    	System.out.println("Sent:\t\t[REGISTER-DENIED|" + RQserver + "|Name_Already_Registered] -> " + clientName + " @ IP: " + clientAddress + ":" + clientPort);
	                    	RQserver++;
	                    }
	                    
	                    //If the clientName is not already registered
	                    else {
	                    	
	                    	//Add client to list. Send out registration accepted packet
	                    	register_client_to_list(clientName,clientAddress.toString(),udp_port,tcp_port);
	                    	String returnMessage = "REGISTERED " + RQserver;
	                    	udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
	                    	udp_datagramSocket.send(udp_datagramPacket_out);
	                    	
	                    	//Print registered packet and increase RQserver
	                    	System.out.println("Sent:\t\t[REGISTERED|" + RQserver + "] -> " + clientName + " @ IP: " + clientAddress + ":" + clientPort);
	                    	RQserver++;
	                    }
	                     
                	}
                	
                	//When the message received is not the correct size
                	else {
                		
                		//Send out registration denied packet
                		String returnMessage = "REGISTER-DENIED " + RQserver + " Wrong_Packet_Size";
                		udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
                    	udp_datagramSocket.send(udp_datagramPacket_out);
                    	
                    	//Print registration denied packet and increase RQserver
                    	System.out.println("Sent:\t\t[REGISTER-DENIED|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
                    	RQserver++;
                	}
                	break;
                }

				// de-registration protocol
                case "DE-REGISTER":{
					//Length 3 for (0)Instruction (1)RQ# (2)ClientName
					if(messageComponents.length == 3){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						String clientName = messageComponents[2];
						System.out.println("Received:\t[DE-REGISTER|" + RQclient + "|" + clientName + "]\tfrom IP: " + clientAddress + ":" + clientPort);

						//If the clientName has been registered
						if(search_client_list(clientName)){
							
							//Call the remove client method
							remove_from_client_list(clientName);
							
							//Send out de-registered packet
							String returnMessage = "DE-REGISTERED " + RQserver + " " + clientName;
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print de-registered packet and increase RQserver
							System.out.println("Sent:\t\t[DE-REGISTERED|" + RQserver + "|" + clientName + "] -> " + clientName + " @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
					}
					
					//When the message received is not the correct size
					else{
						
						//Send out de-register denied packet
						String returnMessage = "DE-REGISTER-FAILED " + RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print de-register denied packet and increase RQserver
						System.out.println("Sent:\t\t[DE-REGISTER-FAILED|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// Publish Protocol
                case "PUBLISH":{
					//Length 4 for (0)Instruction (1)RQ# (2)ClientName (3)FileNames
					if(messageComponents.length == 4){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						String clientName = messageComponents[2];
						String listOfFiles = messageComponents[3];
						System.out.println("Received:\t[PUBLISH|" + RQclient + "|" + clientName  + "|" + listOfFiles +  "]\tfrom IP: " + clientAddress + ":" + clientPort);
						
						//If clientName has not been registered
						if(!search_client_list(clientName)){
							
							//Send out publish-denied packet
							String returnMessage = "PUBLISH-DENIED " + RQserver + " Client_not_registered";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print publish-denied packet and increase RQserver
							System.out.println("Sent:\t\t[PUBLISH-DENIED|" + RQserver + "| Client_not_registered");
							RQserver++;
						}
						
						//If clientName is found in client_list
						else{
							
							//Publish the list of files
							publish_to_clientFile(clientName,listOfFiles);
							
							//Send out published packet
							String returnMessage = "PUBLISHED " + RQserver;
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print published packet and increase RQserver
							System.out.println("Sent:\t\t[PUBLISHED|" + RQserver + "] -> " + clientName + " @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
					}

					//When the message received is not the correct size
					else{
						
						//Send out publish-denied packet
						String returnMessage = "PUBLISH-DENIED " + RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print publish-denied packet and increase RQserver
						System.out.println("Sent\t[PUBLISH-DENIED|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// Remove protocol
                case "REMOVE":{
                	//Length 4 for (0)Instruction (1)RQ# (2)ClientName (3)FileNames
					if(messageComponents.length == 4){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						String clientName = messageComponents[2];
						String listOfFiles = messageComponents[3];
						System.out.println("Received:\t[REMOVE|" + RQclient + "|" + clientName + "|" + listOfFiles + "]\tfrom IP: " + clientAddress + ":" + clientPort);

						//If the clientName has been registered
						if(search_client_list(clientName)){
							
							//Remove the specified file names from the client's data in client_list
							remove_list_info_from_clientFile(clientName,listOfFiles);
							
							//Send out removed packet
							String returnMessage = "REMOVED " + RQserver;
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print removed packet and increase RQserver
							System.out.println("Sent:\t\t[REMOVED|" + RQserver + "] -> " + clientName + " @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
						
						//If clientName is not registered
						else{
							
							//Send out remove-denied packet
							String returnMessage = "REMOVE-DENIED "+ RQserver + " Client_Not_Registered";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print remove-denied packet and increase RQserver
							System.out.println("Sent:\t\t[REMOVE-DENIED|" + RQserver + "|CLIENT_NOT_REGISTERED] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
					}
					
					//When the message received is not the correct size
					else{
						
						//Send out remove-denied packet
						String returnMessage = "REMOVE-DENIED "+ RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print remove-denied packet and increase RQserver
						System.out.println("Sent:\t\t[REMOVE-DENIED|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// retrieve-all protocol
                case "RETRIEVE-ALL":{
                	//Length 2 for (0)Instruction (1)RQ#
					if(messageComponents.length == 2){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						System.out.println("Received:\t[RETRIEVE-ALL|" + RQclient + "]\tfrom IP: " + clientAddress + ":" + clientPort);

						//Verify by IP that the client is registered
						if(search_client_list_by_ip(clientAddress.toString())){

							//Create the string that will contain the client_list_File
							String fileContent = new String();
							try{fileContent = new String(Files.readAllBytes(Paths.get(client_list_File.getPath())));}
							catch(IOException e){e.printStackTrace();}

							//Send out the retrieve packet
							String returnMessage = "RETRIEVE "+ RQserver + " \n" + fileContent; // need to format the return message to be in a table format.
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print the retrieve packet and increase RQserver
							System.out.println("Sent:\t\t[RETRIEVE|"+ RQserver + "|\n" + fileContent + "]" + "-> Unknown @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
						
						//If the client's IP was not registered
						else{
							
							//Send out retrieve-error packet
							String returnMessage = "RETRIEVE-ERROR "+ RQserver + " Client_Not_Registered";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print retrieve-error packet and increase RQserver
							System.out.println("Sent:\t\t[RETRIEVE-ERROR|" + RQserver + "|CLIENT_NOT_REGISTERED] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
							RQserver++;
						}
					}
					
					//When the message received is not the correct size
					else {
						
						//Send out retrieve-error packet
						String returnMessage = "RETRIEVE-ERROR "+ RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print retrieve-error packet and increase RQserver
						System.out.println("Sent:\t\t[RETRIEVE-ERROR|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// Retrieve-infot protocol
                case "RETRIEVE-INFOT":{
                	//Length 3 for (0)Instruction (1)RQ# (2)retrieveName
					if(messageComponents.length == 3){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						String retrieveName = messageComponents[2];
						System.out.println("Received:\t[RETRIEVE-INFOT|" + RQclient + "|" + retrieveName + "]\tfrom IP: " + clientAddress + ":" + clientPort);
						
						//If retrieveName is registered
						if(search_client_list(retrieveName)){
							
							//Set the readers
							FileReader fileReader = new FileReader(client_list_File);
							BufferedReader bufferedReader = new BufferedReader(fileReader);
							
							//currentLine = line currently being analyzed
							String currentLine;
							
							//Read the next line and set currentLine
							while((currentLine = bufferedReader.readLine()) != null){
								
								//If the currentLine contains the retrieveName
								if(currentLine.contains(retrieveName)){
									
									//Send out retrieve-infot packet with the currentLine that the retrieveName is found on
									String returnMessage = "RETRIEVE-INFOT " + RQclient + " " + currentLine;
									udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
									udp_datagramSocket.send(udp_datagramPacket_out);
									
									//Print retrieve-infot packet and increase RQserver
									System.out.println("Sent\t[RETRIEVE-INFOT|" + RQserver + "|" + currentLine + "] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
									RQserver++;
									
									//Close readers and break
									bufferedReader.close();
									fileReader.close();
									break;
								}
							}
						}
						
						//If retrieveName is not registered
						else{
							
							//Send out retrieve-error packet
							String returnMessage = "RETRIEVE-ERROR " + RQclient + "Name_Not_Found";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print retrieve-error packet and increase RQserver
							System.out.println("Sent:\t\t[RETRIEVE-ERROR|" + RQserver + "|Name_Not_Found" + clientAddress);
							RQserver++;
						}
					}
					
					//When the message received is not the correct size
					else {
						
						//Send out retrieve-error packet
						String returnMessage = "RETRIEVE-ERROR "+ RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(), returnMessage.length(), clientAddress, clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print retrieve-error packet and increase RQserver
						System.out.println("Sent:\t\t[RETRIEVE-ERROR|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// Search-file protocol
                case "SEARCH-FILE":{
                	//Length 3 for (0)Instruction (1)RQ# (2)fileName
                	if(messageComponents.length == 3){
                		
                		//Set local variables and print the received message
						RQclient = messageComponents[1];
						String fileName = messageComponents[2];
						System.out.println("Received:\t[SEARCH-FILE|" + RQclient + "|" + fileName + "]\tfrom IP: " + clientAddress + ":" + clientPort);

						//If the client is registered
						if(search_client_list_by_ip(clientAddress.toString())){
							
							//Create and initialize listOf by calling method responsible for searching clinet_list
							String listOf = search_client_list_by_file(fileName);
							
							//Send out search-file packet
							String returnMessage = "SEARCH-FILE " + RQserver + " " + listOf;
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort); // need to add tcp port
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print search-file packet and increase RQserver
							System.out.println("Sent:\t\t[SEARCH-FILE|" + RQserver + "|" + listOf + "]");
							RQserver++;
						}
						
						//If the client is not registered
						else{
							
							//Send out search-error packet
							String returnMessage = "SEARCH-ERROR " + RQclient + " Client not registered";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print search-error packet and increase RQserver
							System.out.println("Sent:\t\t[SEARCH-ERROR|" + RQserver + "|CLIENT_NOT_REGISTERED");
							RQserver++;
						}
					}
                	
                	//When the message received is not the correct size
                	else{
                		
                		//Send out search-error packet
						String returnMessage = "SEARCH-ERROR "+ RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort);
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print search-error packet and increase RQserver
						System.out.println("Sent:\t\t[SEARCH-ERROR|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
                	break;
                }

				// Mobility Protocol
				case "UPDATE-CONTACT":{
					//Length 5 for (0)Instruction (1)RQ# (2)ClientName (3)UDP_Port (4)TCP_Port
					if(messageComponents.length == 5){
						
						//Set local variables and print the received message
						RQclient = messageComponents[1];
						String clientName = messageComponents[2];
						String udp_port = messageComponents[3];
						String tcp_port = messageComponents[4];
	                    System.out.println("Received:\t[UPDATE-CONTACT|" + RQclient + "|" + clientName + "|" + udp_port + "|" + tcp_port + "]\tfrom IP: " + clientAddress + ":" + clientPort);

						//If the client name has been registered
						if(search_client_list(clientName)){
							try{
								//Create reader, buffer, and strings used to modify contents of client_list
								BufferedReader file = new BufferedReader(new FileReader(client_list_File));
								StringBuffer buffer = new StringBuffer();
								String currentLine = new String();
								String newLine = new String();
								
								//If there is another line in client_file set currentLine
								while((currentLine = file.readLine()) != null){
									
									//If the currentLine contains the clientName to update
									if(currentLine.contains(clientName)){
										
										//Split the currentLine into moddedLine; [0]:Name [1]:IP [2]:udp_port [3]:tcp_port [4]:fileNames(might not exist)
										String[] moddedLine = currentLine.split("\t");
										moddedLine[1] = clientAddress.toString();
										moddedLine[2] = udp_port;
										moddedLine[3] = tcp_port;
										
										//For each moddedLine element, append to newLine
										for (String ml : moddedLine) {
											newLine = newLine + ml + "\t";
										}
										
								    	//Removes the "\t" at the end of newLine
								    	if (newLine!=null && newLine.length()>0 && newLine.charAt(newLine.length()-1)=='\t') {
								    		newLine = newLine.substring(0, newLine.length()-1);
								        }
								    	
								    	//Sets currentLine to the newLine
								    	currentLine = newLine;
									}
									
									//Add currentLine to buffer
									buffer.append(currentLine + "\n");
								}
								file.close();
	
								//Write the buffer to client_list
								FileOutputStream fileOut = new FileOutputStream(client_list_File);
								fileOut.write(buffer.toString().getBytes());
								fileOut.close();
							}
							catch(Exception e){e.printStackTrace();}
							
							//Send out update-confirmed packet
							String returnMessage = "UPDATE-CONFIRMED " + RQserver + " Client_Updated";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort); // need to add tcp port
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print update-confirmed packet and increase RQserver
							System.out.println("Sent:\t\t[UPDATE-CONFIRMED|" + RQserver + "|Client_Info_Updated]" + clientAddress);
							RQserver++;
						
						}
						
						//If the client name has not been registered
						else{
							
							//Send out update-denied packet
							String returnMessage = "UPDATE-DENIED " + RQserver + "Client_name_not_found";
							udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort); // need to add tcp port
							udp_datagramSocket.send(udp_datagramPacket_out);
							
							//Print update-denied packet and increase RQserver
							System.out.println("Sent:\t\t[UPDATE-DENIED|" + RQserver + "|Client_Name_Not_Found]" + clientAddress);
							RQserver++;
						}
					}
					
					//When the message received is not the correct size
					else{
						
						//Send out update-denied packet
						String returnMessage = "UPDATE-DENIED " +RQserver + " Wrong_Packet_Size";
						udp_datagramPacket_out = new DatagramPacket(returnMessage.getBytes(),returnMessage.length(),clientAddress,clientPort); // need to add tcp port
						udp_datagramSocket.send(udp_datagramPacket_out);
						
						//Print update-denied packet and increase RQserver
						System.out.println("Sent:\t\t[REMOVE-DENIED|" + RQserver + "|Wrong_Packet_Size] -> Unknown @ IP: " + clientAddress + ":" + clientPort);
						RQserver++;
					}
					break;
				}

                default:{
                	//Sends back original client packet
                	udp_datagramSocket.send(udp_datagramPacket_in);
                	break;
                }
                }

            } catch(IOException e){
                e.printStackTrace();
                break;
            }
        }
    }



    public static void main(String[]args) throws SocketException, InterruptedException {
        DatagramSocket udp_datagramSocket = new DatagramSocket(server_udp_portNum);
        Server server = new Server(udp_datagramSocket);
		Thread  thread = new Thread(server);
		thread.start();
		thread.join();
    }


	@Override
	public void run() {
		this.set_client_list("client_list.txt");
		this.receiveThenSendMessage();
	}
}
