import java.net.*;

public class Peer_UDP_Handler extends Client implements Runnable{
	private DatagramPacket udp_datagramPacket_out,udp_datagramPacket_in;
	private byte[] bufferOut;
	private byte[] bufferIn = new byte[256];
	private String msgToHandle;
		
	
	public Peer_UDP_Handler(DatagramSocket ds, InetAddress ip, String msg) {
		datagramSocket = ds;
		inetAddress = ip;
		msgToHandle = msg;
	}
	
	public void SendThenReceiveUDP() {
	    try{
	    	//Increase serverRQ by one
	        serverRQ += 1;
	        
	        //Set bufferOut to message that will be sent. Print message
	        bufferOut = msgToHandle.getBytes();
	        System.out.println("Sending:\t" + msgToHandle);
	
	        //Send the message
	        udp_datagramPacket_out = new DatagramPacket(bufferOut, bufferOut.length,inetAddress,server_udp_portNum);
	        datagramSocket.send(udp_datagramPacket_out); // send through sockets
	        
	        //Receive the server's response packet. Blocks at .receive() until a udp packet is received
	        udp_datagramPacket_in = new DatagramPacket(bufferIn,bufferIn.length);
	        datagramSocket.receive(udp_datagramPacket_in);
	        
	        //Create a message string from the received packet
	        String serverMessage = new String(udp_datagramPacket_in.getData(),0,udp_datagramPacket_in.getLength());
	        System.out.println("Server sent:\t" + serverMessage);
	        
	        //TODO parse the received message
	    }
	    catch(Exception e){e.printStackTrace();}
	}
	
	@Override
	public void run() {
		SendThenReceiveUDP();
	}

}
