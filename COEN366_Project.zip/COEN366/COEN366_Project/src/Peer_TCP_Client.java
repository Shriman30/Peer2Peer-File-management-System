import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class Peer_TCP_Client extends Client implements Runnable{
	private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private String msg, ip;
    private int port;
    private ArrayList<String> receivedList;
    
    //Constructor takes message to send from client.java.
    public Peer_TCP_Client(String msg, String ip, int port) {
		this.msg = msg;
		this.ip = ip;
		this.port = port;
	}

	public void startConnection(String ip, int port)  {
    //Starts a tcp connection with destination's ip and port. Sets in and out.
        try {
        	clientSocket = new Socket(ip, port);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
        	in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		} catch (IOException e) {e.printStackTrace();}
    }

    public void sendMessage(String msg) {
    	//Sends msg to the connected tcp socket
		out.println(msg);
	}
    
	private void receiveMessages() {
		//Gets a response and prints to console
		
		try {
			String received = new String();
			String currLine;
			
			//While loop will end when out.close() in Peer_TCP_Server is called
			while ((currLine = in.readLine()) != null) {
				
				//Change the *$*$* back to carriage returns
				received = currLine.replace("*$*$*", "\n");
				
				//Print the received message
				System.out.println("Received:\t" + received);
			}
		} catch (IOException e1) {e1.printStackTrace();}
	}
	
    public void stopConnection()  {
    	//closes in and out as well as the socket connection
        try {
        	in.close();
            out.close();
            clientSocket.close();
		}
        catch (IOException e) {e.printStackTrace();}
    }
	
	
	
	@Override
	public void run() {
		System.out.println("Peer_TCP_Client Thread has started.");
		startConnection(ip,port);
		sendMessage(msg);
		receiveMessages();
		stopConnection();
	}


	
	
}
