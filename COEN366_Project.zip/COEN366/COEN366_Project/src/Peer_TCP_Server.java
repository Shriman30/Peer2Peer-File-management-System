import java.io.*;
import java.util.ArrayList;
import java.net.*;

public class Peer_TCP_Server extends Client implements Runnable{
	private final static int CHUNK_SIZE = 200;
	private Socket tcp_clientSocket;
	private PrintWriter out;
	private BufferedReader in;
	private int responseRQ = 0;
	
	public void Process_TCP_Message(String receivedMsg) {
		//This is where we process incoming messages
		String msgComponents[] = receivedMsg.split(" ");
		String instruction = msgComponents[0].toUpperCase();
		
		switch (instruction) {
		case "DOWNLOAD": {
			//Check That the length of [DOWNLOAD|RQ|fileName] packet is 3
			if (msgComponents.length == 3) {
				System.out.println("Received:\t[DOWNLOAD|" + msgComponents[1] + "|" + msgComponents[2] + "]");
				
				//Check if the file exists, and if not, send download-error packet
				File f = new File(msgComponents[2]);
				if(!f.isFile()) { 
					out.println("DOWNLOAD-ERROR " + responseRQ + " File_Not_Available");
					System.out.println("DOWNLOAD-ERROR " + responseRQ + " File_Not_Available");
					responseRQ++;
					out.close();
					break;
				}
				
				//Spilt the file into an ArrayList of strings
				ArrayList<String> msgChunks = splitFile(msgComponents[2]);
				
				//Send out [FILE|RQ|fileName|chunk#|Text] and print
				//The text will have all carriage returns replaced with "*$*$*"
				for (int i = 0; i < msgChunks.size() - 1; i++){
					String replaceENDL = msgChunks.get(i).replace("\r\n", "*$*$*");
					replaceENDL = replaceENDL.replace("\r", "*$*$*");
					replaceENDL = replaceENDL.replace("\n", "*$*$*");
					out.println("FILE " + responseRQ + " " + msgComponents[2] + " " + i + " " + replaceENDL);
					System.out.println("Sent:\tFILE " + responseRQ + " " + msgComponents[2] + " " + i + " " + replaceENDL);
					responseRQ++;
				}
				
				//Send the last [FILE-END|RQ|fileName|chunk#|Text] and print
				String replaceENDL = msgChunks.get(msgChunks.size()-1).replace("\r\n", "*$*$*");
				replaceENDL = replaceENDL.replace("\r", "*$*$*");
				replaceENDL = replaceENDL.replace("\n", "*$*$*");
				out.println("FILE-END " + responseRQ + " " + msgComponents[2] + " " + (msgChunks.size()-1) + " " + replaceENDL);
				System.out.println("Sent:\tFILE-END " + responseRQ + " " + msgComponents[2] + " " + (msgChunks.size()-1) + " " + replaceENDL);
				responseRQ++;
				
				//Close the PrintWriter
				out.close();
			}
			
			//If the length of [DOWNLOAD|RQ|fileName] packet is not 3
			else {
				out.println("DOWNLOAD-ERROR " + responseRQ + " Wrong_Packet_Size");
				System.out.println("DOWNLOAD-ERROR " + responseRQ + " Wrong_Packet_Size");
				responseRQ++;
			}
			break;
		}
		
		default: {
			//If any other messages come in
			
			break;
		}
		}


	}

	public ArrayList<String> splitFile(String fileName) {
		//This method will split a file into chunks and return the chunks as an ArrayList
		ArrayList<String> chunks = new ArrayList<String>();
		
		try {
			int value;
			StringBuilder wholeFile = new StringBuilder();
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			
			//Get the whole file into a StringBuilder
			while((value = reader.read()) != -1) {
				wholeFile.append((char)value);
			}
			
			//Get the length of the file
			int fileLength = wholeFile.length();
			
			//NumChunks rounds down in the event that its a decimal
			int numChunks = fileLength/CHUNK_SIZE;
			
			//Create the chunks (excluding the last one) and add it to the ArrayList
			for (int i = 0; i < numChunks; i++) {
				String chunk = wholeFile.toString().substring(i*CHUNK_SIZE, i*CHUNK_SIZE + CHUNK_SIZE);
				chunks.add(chunk);
			}
			
			//If the file length doesn't split perfectly into full chunks, we need to create the last one
			if(fileLength % CHUNK_SIZE != 0) {
				int startingOffset = numChunks * CHUNK_SIZE;
				int remainder = fileLength % CHUNK_SIZE;
				
				String chunk = wholeFile.toString().substring(startingOffset, startingOffset + remainder);
				chunks.add(chunk);
			}
			
			//Close the reader
			reader.close();	
		}
		catch (FileNotFoundException e) {e.printStackTrace();} 
		catch (IOException e) {e.printStackTrace();}

		//Return the ArrayList of chunks
		return chunks;
	}
	
	


    //Method used to send the contents of the targeted file in chunks
    public void sendFragementedFileToRequestingClient(String fileName, int chunkSize){
		//String [] fragementedArrayToSend = fragementTextFileIntoChunks("",chunkSize);
		//should call getCharCount here on the content of file1
		/*
		 This method essentially requires us to understand the concept of fragmentation.
		 What happens basically is that the client will read the file and send it to another client in chunks of less than 200 characters
		 (So we need a variable for that).

		 After scanning the entire document, we should save the number of characters that exists in the file. (We need a variable charCount).
		 We then need to divide numOfChars by 200 in order to determine the number of packets or messages that will be sent to the client who is requesting the download.
		 Each packet can therefore have up to 200 characters stored that would have to be sent.
		 We can :
		 	- Scan for 200 characters, copy them into a buffer and send the content of that buffer as a string to the requesting client as a message.
*/
		// Put the content of the targeted text file into a string.
		int count=0;
		BufferedReader reader;

		try {

			reader =new BufferedReader(new FileReader(fileName));
			String line;
			StringBuilder stringBuilder = new StringBuilder();
			//String lineSeparator = System.getProperty("line.separator");

			while((line = reader.readLine()) != null){
				stringBuilder.append(line);

				while(stringBuilder.length() >=chunkSize){
					String c = stringBuilder.substring(0,chunkSize);
					// do something with that string
					System.out.println(count + " "+c);
					out.println(count + " "+ c);
					count++;
					// add whatever that is left to the next chunk
					stringBuilder = new StringBuilder(stringBuilder.substring(chunkSize));

				}
			}

			//
			String c = stringBuilder.toString();
			System.out.println(count + " "+ c);
			out.println(count + " "+c);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}


    }
	// this method is used to split the file into chunks based on character count.

	public String []  fragementTextFileIntoChunks(String temp, int chunkSize){
		int sizeOfArray = (int) Math.ceil((double) temp.length()/chunkSize);
		String [] fragementFileArray = new String[sizeOfArray];

		int index =0;
		for (int i =0; i<temp.length();i = i+chunkSize){
			if(temp.length()-i <chunkSize){
				fragementFileArray[index++] = temp.substring(i);
			}
			else{
				fragementFileArray[index++] = temp.substring(i,i+chunkSize);
			}
		}

		return fragementFileArray;
	}

	
	public void stop() throws IOException {
		//Stops the in and out. Closes all sockets
        in.close();
        out.close();
        tcp_clientSocket.close();
        tcp_serverSocket.close();
    }
	
	
	
	@Override
	public void run(){
		System.out.println("Peer_TCP_Server Thread has started.");
		try { 
	    	System.out.println("Client listening for TCP on port#: " + tcp_serverSocket.getLocalPort());
	    	
	    	//Listening loop that runs while client is not broadcasting SHUTDOWN
	    	while (broadcastState.equals(State.RUNNING)) {
	    		//Accept() blocks and returns a socket when a connection is made
	    		tcp_clientSocket = tcp_serverSocket.accept();
                System.out.println("New client connected");
                
                //Sets in and out when a connection is made
                out = new PrintWriter(tcp_clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(tcp_clientSocket.getInputStream()));

                //Gets the incoming message
                String receivedMessage = in.readLine();
                
                //Calls the processing method on the receivedMessage
                Process_TCP_Message(receivedMessage);
            }
	    	
	    //
	    stop();
		}
	    catch (IOException e) {	e.printStackTrace(); }
	    return;
	}
	

	
}

